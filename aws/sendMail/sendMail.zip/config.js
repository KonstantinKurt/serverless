module.exports = {
   user:`gettestmail14@gmail.com`,
   password:`cubex1986` ,
   
};